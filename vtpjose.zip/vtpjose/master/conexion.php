<?phP
    //Conexión a la base de datos concepto con el usuario root y contraseña 1984
    $conexion = mysqli_connect('localhost','root','1984','concepto');
    if(mysqli_connect_error()){
        die('No se puede conectar a la base de datos'.mysqli_connect_error());
    }
?>