<?php 
	session_start();

	if(isset($_SESSION['user'])){
 ?>

 <!DOCTYPE html>
<html>

<head>
	<title>Inicio</title>
	<?php require_once "scripts.php"; ?>
</head>

<body style="background-color: gray">
<br><br><br>
	<div class="container">
		<div class="row">		
			<div class="col-sm-4"></div>
			 <div class="col-sm-4">
			  <div class="panel panel-primary">
			   <div class="panel panel-heading" align="center">MENU</div>
			     <p></p>
				  <div class="panel panel-body">
				   <div style="text-align: center;">
				    <p></p>
					<br>
				     <a href="registro.php" class="btn btn-success btn-lg btn-block">Registro Usuarios</a>
				      <p></p>
					  <br>
				       <a href="master/registrar.php" class="btn btn-success btn-lg btn-block">Informacion Visita Tecnica</a>
				        <p></p>
						<br>
				         <a href="crwmaster/lista.php" class="btn btn-success btn-lg btn-block">Estado</a>
				          <p></p>
						  <br>
						  <br>
						  <br>
				               <a href="php/salir.php" class="btn btn-primary  btn-lg btn-block">Salir </a>
				                <p></p>
	               </div>
		          </div>	
				</div>
			</div>
		</div>
	</div>
	
</body>
</html>

<?php
} else {
	header("location:index.php");
	}
 ?>
