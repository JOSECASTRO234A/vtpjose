

<?php 
     //Conexión a la base de datos apphonor con el usuario root y contraseña 1984
	function conexion()
	{
		return $conexion=mysqli_connect("localhost","root","1984","apphonor");
	}

 ?>