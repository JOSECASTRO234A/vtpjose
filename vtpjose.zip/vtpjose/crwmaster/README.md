# CRUD EN PHP
Hola, aquí les traigo un CRUD acronimo de Crear, Leer, Actualizar y Borrar (Create, Read, Update and Delete en inglés) que he desarrollado en PHP.
