<?php
include('conexion.php');
$consulta = 'select * from usuarios';
$resultado = mysqli_query($conexion,$consulta);
$tabla =<<<FIN
<table>
<tr><th>Cliente</th><th>Sucursal</th><th>Ciudad</th><th>Novedad</th><th colspan="2">Accion</th></tr>
FIN;

while($registro=mysqli_fetch_assoc($resultado)){
    $tabla.='<tr>';
    $tabla.="<td>{$registro['nombres']}</td>";
    $tabla.="<td>{$registro['app']}</td>";
    $tabla.="<td>{$registro['apm']}</td>";
    $tabla.="<td>{$registro['area']}</td>";
    $tabla.="<td><a href=borrar.php?id={$registro['id']}>Borrar</a></td>";
    $tabla.="<td><a href=editar.php?id={$registro['id']}>Editar</a></td>";
    $tabla.='</tr>';
}
$tabla.='</table>';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/estilos.css">
    <title>lista</title>
</head>
<body>
    <form action="../inicio.php" method='post'>
    <div class="contenedor">
        <div class="cabecera">INFORMACION REGISTRADA VISITAS</div>
        <div class="contenido">
        <div class="tabla">
        <?php echo $tabla; ?>
        <p>
		<input type="submit" value="INICIO" color="#0000FF" >
        </p>
        </div>

        </div>
    </div>
</body>
</html>